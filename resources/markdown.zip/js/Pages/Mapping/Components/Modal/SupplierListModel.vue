<script>
import { defineComponent } from "vue";
import { Link } from "@inertiajs/inertia-vue3";
import Loading from "vue-loading-overlay";
import "vue-loading-overlay/dist/css/index.css";
import { toast } from "vue3-toastify";
import { copyText } from "vue3-clipboard";
import Modal from '@/Components/Modal.vue';
import axios from "axios";
import SectionLoader from "../../../../Components/SectionLoader.vue";
import CopyLinkButton from "../../../../Components/CopyLinkButton.vue";
import utils from "../../../../utils";
import { Inertia } from "@inertiajs/inertia";
export default defineComponent({
    props: ["id", "show"],
    setup() {
        const doCopy = (link) => {
            copyText(link, undefined, (error, event) => {
                if (error) {
                    toast.info("Can not copy", {
                        autoClose: 1000,
                    });
                } else {
                    toast.success("Copied", {
                        autoClose: 1000,
                    });
                }
            });
        };

        return {
            doCopy,
        };
    },
    data() {
        return {
            projects: [],
            isLoading: false,
            isFullScreenLoading: false,
        }
    },
    components: {
        Link,
        Loading,
        Modal,
        SectionLoader,
        CopyLinkButton
    },
    watch: {
        id: {
            deep: true,
            async handler() {
                this.isLoading = true;
                const response = await axios.get(`/project-link/${this.id}/suppliers`);
                this.projects = response?.data?.suppliers;
                this.isLoading = false;
            }
        }
    },
    methods: {
        async updateStatus(id, e) {
            this.isFullScreenLoading = true;
            await utils.changeStatus(route("supplier.status"), {
                id: id,
                status: e,
            });
            this.isFullScreenLoading = false;
        },

        sapmlingEdit(id) {
            this.isFullScreenLoading = true;
            Inertia.get(route("sampling.edit", id))
        }
    }
});
</script>
<template>
    <Modal :show="show" @onhide="$emit('hidemodal')" title="Suppliers" :isFullscreen="true" :id="id">
        <loading :active="isFullScreenLoading" :can-cancel="true" :is-full-page="isFullPage"></loading>
        <div class="card-body p-0">
            <SectionLoader v-if="isLoading" :width="40" :height="40" />
            <div class="border rounded-3 p-5 mb-3 shadow-sm" v-else-if="projects?.length > 0"
                v-for="(project, index) in projects" :key="index">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="flex-1">
                        <Link class="text-gray-800 text-hover-primary fs-6 fw-bold" :href="`/mapping/${project.id}`">
                        {{ project.supplier?.supplier_name }} ({{
                            project.supplier?.display_name
                        }})</Link>
                        <span class="text-muted fw-semibold d-block fs-7"><i class="bi bi-people-fill me-2"></i>{{
                            project?.project_name }} ({{
        project?.country?.iso2
    }})</span>
                    </div>
                    <div class="flex-1 fw-bold" v-if="$page.props.user.role.role.slug != 'user'">
                        <span>${{ project.cpi }}/-CPI</span>
                    </div>
                    <div class="flex-1">
                        <CopyLinkButton :link="project.supplier_link" v-if="$page.props.user.role.role.slug != 'user'"
                            tooltip="Copy project link" />
                        <CopyLinkButton :link="$page.props.ziggy.url +
                            '/surveyRoute/init/' +
                            project.id +
                            '/' +
                            $page.props.user.id" v-else />
                    </div>
                    <div class="flex-1 text-end" v-if="$page.props.user.role.role.slug != 'user'">
                        <div class="form-switch form-check-solid d-block form-check-custom form-check-success">
                            <input class="form-check-input h-20px w-30px" type="checkbox"
                                @input="updateStatus(project?.supplier?.id, $event.target.checked)"
                                :checked="project?.supplier?.status == 1 ? true : false" />
                            <label class="form-check-label"> Status </label>
                        </div>
                    </div>
                    <div class="flex-1 text-end" v-if="$page.props.user.role.role.slug != 'user'">
                        <button class="btn btn-icon btn-outline btn-light btn-circle me-5" :id="`dropdown-${project.id}`"
                            data-bs-toggle="dropdown">
                            <i class="bi bi-three-dots-vertical"></i>
                        </button>
                        <div class="text-left dropdown-menu menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-semibold fs-7 w-125px py-4"
                            :aria-labelled:by="`dropdown-${project.id}`">
                            <div class="menu-item px-3">
                                <!-- <Link :href="`/sampling/${project.id}/edit`" class="menu-link"><i
                                    class="bi bi-pencil me-2"></i>Edit
                                </Link> -->
                                <span @click="sapmlingEdit(project.id)" class="menu-link"><i
                                        class="bi bi-pencil me-2"></i>Edit</span>
                            </div>
                            <div class="menu-item px-3">
                                <span @click="confirmDelete(index)" class="menu-link"><i
                                        class="bi bi-trash3 me-2"></i>Delete</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="separator separator-dashed my-4"></div>
                <ul class="nav d-flex justify-content-between fw-bold text-center">
                    <li class="nav-item row">
                        <span>
                            {{ project.sample_size }}
                        </span>
                        <span class="text-gray-400">Sample Size</span>
                    </li>
                    <li class="nav-item row">
                        <span>
                            {{ project.reports.total_clicks }}
                        </span>
                        <span class="text-gray-400">Total Clicks</span>
                    </li>
                    <li class="nav-item row">
                        <span>
                            {{ project.reports.complete }}
                        </span>
                        <span class="text-gray-400"> Completes</span>
                    </li>
                    <li class="nav-item row">
                        <span>
                            {{ project.reports.terminate }}
                        </span>
                        <span class="text-gray-400">Terminates</span>
                    </li>
                    <li class="nav-item row">
                        <span>
                            {{ project.reports.quotafull }}
                        </span>
                        <span class="text-gray-400">Quotafull</span>
                    </li>
                    <li class="nav-item row">
                        <span>
                            {{ project.reports.security_terminate }}
                        </span>
                        <span class="text-gray-400">Security Terminates</span>
                    </li>
                    <li class="nav-item row">
                        <span>
                            {{ project.reports.incomplete }}
                        </span>
                        <span class="text-gray-400">Incompletes</span>
                    </li>
                    <li class="nav-item row">
                        <span>
                            {{ project.reports.total_ir }}
                        </span>
                        <span class="text-gray-400">Incidence Ratio</span>
                    </li>
                </ul>
            </div>
            <div v-else style="height: 354px;" class="w-100 d-flex align-items-center justify-content-center pt-10 pb-10">
                <div class="text-center py-10">
                    <img src="/assets/images/emptyrespondent.png" style="height: 200px" />
                    <div class="fw-bold fs-2 text-gray-900 mt-5">
                        No Supplier Found!
                    </div>
                </div>
            </div>
        </div>
    </Modal>
</template>
